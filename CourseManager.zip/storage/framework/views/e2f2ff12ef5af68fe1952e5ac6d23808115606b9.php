<head>
    <?php if(Auth::user()->role == 1): ?>
        <?php if(Auth::user()->EmployeeDetail->position_id == 3): ?>
        <meta http-equiv="refresh" content="0; url=<?php echo e(route('courses.index')); ?>" />
        <?php else: ?>
        <meta http-equiv="refresh" content="0; url=<?php echo e(route('classes.index')); ?>" />
        <?php endif; ?>
    <?php elseif(Auth::user()->role == 2): ?>
    <meta http-equiv="refresh" content="0; url=<?php echo e(route('classes.index')); ?>" />
    <?php endif; ?>
</head><?php /**PATH E:\CourseManager\resources\views/dashboard.blade.php ENDPATH**/ ?>